set nocount on

DECLARE @cmdID INT
DECLARE @cmd nvarchar(2000)
DECLARE @cmdFinal nvarchar(2000)
DECLARE @getCMDCursorID CURSOR SET @getCMDCursorID = CURSOR
FOR
SELECT id as id1, cmd as cmd1 from [temp_command] where executed <> 1 or executed is null order by ID
OPEN @getCMDCursorID
FETCH NEXT
FROM @getCMDCursorID
INTO @cmdID,@cmd
WHILE @@FETCH_STATUS = 0
BEGIN

select @cmdFinal = cmd from [temp_command] where id = @cmdID
    BEGIN TRY

    exec (@cmdFinal)
    END TRY
    BEGIN CATCH
    update temp_command set [executed] = 3 where id = @cmdID
    END CATCH
FETCH NEXT
FROM @getCMDCursorID
INTO @cmdID,@cmd
END
CLOSE @getCMDCursorID
DEALLOCATE @getCMDCursorID