WHENEVER SQLERROR EXIT FAILURE;
ALTER SESSION SET current_schema = REPLACE_SCHEMA;
set serveroutput on size 999999;
declare
  commandExists number;
  skipExists number;
begin
  select count(*) into commandExists from all_objects where object_name = 'TEMP_COMMAND' and owner=sys_context('userenv', 'current_schema' );
  if commandExists > 0 then
    execute immediate 'drop table TEMP_COMMAND';
  end if;
  select count(*) into skipExists from all_objects where object_name = 'TEMP_SKIPPED' and owner=sys_context( 'userenv', 'current_schema' );
  if skipExists > 0 then
    execute immediate 'drop table TEMP_SKIPPED';
  end if;
end;
/
create table temp_command(
  seq       number,
  command   varchar2(2000),
  executed  number default 0
);
create table temp_skipped(
  id       number
);
DECLARE
  seq number;
  ID number;
  viewExists number;
  sch varchar2(200);
  hasNewViews NUMBER;
BEGIN
    seq := 0;
    select sys_context( 'userenv', 'current_schema' ) into sch from dual;
    FOR c IN (
        select distinct  tenant.ID as tenantID, tenant.name as tenantName
        from ossys_Tenant tenant
        inner join ossys_espace userProvider on tenant.ESPACE_ID = userProvider.ID
        inner join   (select distinct USER_PROVIDER_KEY,espace_name name from  ossys_espace_version ) nameEspace on  nameEspace.USER_PROVIDER_KEY = userProvider.SS_KEY 
		and ( nameEspace.name like tenant.name||'(deleted%' or nameEspace.name = tenant.name )
        where userProvider.IS_ACTIVE = 1
        and tenant.NAME != userProvider.NAME
        order by tenant.ID
    )
    LOOP
        seq := seq + 1;
        SELECT count(1) INTO hasNewViews
        FROM
            all_views v
            JOIN all_objects o ON v.owner = o.owner AND v.view_name = o.object_name
        WHERE
            v.view_name IN (
                SELECT
                    DISTINCT Base_View_Name || '_T' || to_char(c.tenantID)  AS viewname
                from
                    ossys_Entity
                where
                    MULTITENANT = 1
                    and IS_ACTIVE = 1
                    and Base_View_Name != ' '
                    and Base_View_Name is not null
            )
            AND v.owner = sch
            AND o.created < to_date('2022-13-dd hh:mm:ss', 'YYYY-MM-DD HH24:MI:SS')
        ;
        IF hasNewViews > 0 then
            insert into temp_skipped (id) values (c.tenantID);
             dbms_output.put_line('Skipped Tenant with ID [' || to_char(c.tenantID) ||  '] - ' || c.tenantName);
            COMMIT;
            CONTINUE;
        END IF;
        --dbms_output.put_line('Processing Tenant with ID [' || to_char(c.tenantID) ||  '] - ' || c.tenantName);
        insert into temp_command (seq, command) values (seq, '--Processing tenant.ID ' || to_char(c.tenantID) ||  ' - ' || c.tenantName);
        FOR x IN (
            SELECT
                DISTINCT Base_View_Name || '_T' || to_char(c.tenantID)  AS viewname
            from
                ossys_Entity
            where
                MULTITENANT = 1
                and IS_ACTIVE = 1
                and Base_View_Name != ' '
                and Base_View_Name is not null
        )
        LOOP
            SELECT count(1) INTO viewExists FROM all_views WHERE owner = sch AND view_name = upper(x.viewname);
            IF viewExists > 0 THEN
                seq := seq + 1;
                insert into temp_command (seq, command) values (seq, 'DROP VIEW ' || sch || '.' || x.viewname);
            END IF;
        END LOOP;
    seq := seq + 1;
    insert into temp_command (seq, command) values (seq, 'DELETE from ' || sch || '.ossys_Site_Property where Tenant_Id = ' || to_char(c.tenantID));
    seq := seq + 1;
    insert into temp_command (seq, command) values (seq, 'DELETE from ' || sch || '.ossys_Cyclic_Job where Tenant_Id =  ' || to_char(c.tenantID));
    seq := seq + 1;
    insert into temp_command (seq, command) values (seq, 'DELETE from ' || sch || '.ossys_Tenant where ID = ' || to_char(c.tenantID));
    seq := seq + 1;
    insert into temp_command (seq, command) values (seq, 'commit');
    commit;
    END LOOP;
END;