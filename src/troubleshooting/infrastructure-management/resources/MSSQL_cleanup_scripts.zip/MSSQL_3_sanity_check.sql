if not exists 
    (select 
        distinct  tenant.ID as tenantID, tenant.name as tenantName
    from 
        ossys_Tenant tenant
        inner join ossys_espace userProvider on tenant.ESPACE_ID = userProvider.ID
        inner join (select distinct USER_PROVIDER_KEY,espace_name name from  ossys_espace_version )
        nameEspace on  nameEspace.USER_PROVIDER_KEY = userProvider.SS_KEY and ( nameEspace.name like tenant.name+'(deleted%' or nameEspace.name = tenant.name )
    where 
        userProvider.IS_ACTIVE = 1
        and tenant.NAME != userProvider.NAME
        and tenant.Id not in (select id from temp_skipped))
begin
print 'Tenant cleanup was successful. Please export and save locally the content of tables temp_command and temp_skipped'
end
else
print 'Tenant cleanup failed - please export the content of the tables: temp_command, temp_skipped, ossys_tenant, and sys.views and follow up on the support case'