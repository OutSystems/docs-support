if exists (select 1 from sys.tables where name='temp_command') 
begin
drop table temp_command
end
if exists (select 1 from sys.tables where name='temp_skipped') 
begin
drop table temp_skipped
end
