WHENEVER SQLERROR EXIT FAILURE;
ALTER SESSION SET current_schema = REPLACE_SCHEMA;
set serveroutput on size 999999;
declare
  commandExists number;
  skipExists number;
begin
  select count(*) into commandExists from all_objects where object_name = 'TEMP_COMMAND' and owner=sys_context('userenv', 'current_schema' );
  if commandExists > 0 then
    execute immediate 'drop table TEMP_COMMAND';
  end if;
  select count(*) into skipExists from all_objects where object_name = 'TEMP_SKIPPED' and owner=sys_context( 'userenv', 'current_schema' );
  if skipExists > 0 then
    execute immediate 'drop table TEMP_SKIPPED';
  end if;
end;