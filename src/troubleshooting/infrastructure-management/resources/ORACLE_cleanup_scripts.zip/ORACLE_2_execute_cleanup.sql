WHENEVER SQLERROR EXIT FAILURE;
ALTER SESSION SET current_schema = REPLACE_SCHEMA;

BEGIN
  for c in (select seq, command from temp_command where executed = 0 AND command NOT LIKE '--%' order by seq)
  LOOP
    --update temp_command set executed = 1 where seq = c.seq;
    EXECUTE IMMEDIATE c.command;
  END LOOP;
END;