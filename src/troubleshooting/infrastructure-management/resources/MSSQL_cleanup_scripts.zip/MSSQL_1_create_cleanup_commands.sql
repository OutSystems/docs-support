set nocount on

-- create temporary tables
if exists (select 1 from sys.tables where name='temp_command') 
begin
drop table temp_command
end
if exists (select 1 from sys.tables where name='temp_skipped') 
begin
drop table temp_skipped
end

create table temp_command
(
[ID] [int] IDENTITY(1,1) NOT NULL,
[cmd] nvarchar(2000),
[executed] int null
)

create table temp_skipped(
[ID] [int]
)

-- add control variable to only delete Tenants created after the Deploy was clicked
DECLARE @DeployTime datetime;
SELECT 
  @DeployTime = Min([TIME_STAMP])
FROM 
  OSSYS_ASYNC_OP_STATE 
  JOIN OSSYS_ASYNC_OP_UPGRADE_DETAIL ON OSSYS_ASYNC_OP_STATE.ID = OSSYS_ASYNC_OP_UPGRADE_DETAIL.ID
WHERE
  OPERATION_TYPE = 'Modules Deploy'

if (@DeployTime is null)
begin
	PRINT 'The Deploy button was not clicked. Please confirm this in Service Center > Factory > Upgrades.';
	THROW 51000, 'Stopping procedure execution because the known issue of 11.18 was not triggered.', 0;
end

PRINT 'The Deploy button was clicked on ' + cast(@DeployTime as varchar(50));

-- identify which Tenants match RPM-3448 conditions
DECLARE @ID INT
DECLARE @Name1 varchar(200)
DECLARE @DropText varchar(250);
DECLARE @IdList varchar(2500);
DECLARE @getCursorID CURSOR SET @getCursorID = CURSOR
FOR
select 
  distinct  tenant.ID as tenantID, tenant.name as tenantName
from 
  ossys_Tenant tenant
  inner join ossys_espace userProvider on tenant.ESPACE_ID = userProvider.ID
  inner join (select distinct USER_PROVIDER_KEY,espace_name name from  ossys_espace_version )
  nameEspace on  nameEspace.USER_PROVIDER_KEY = userProvider.SS_KEY and ( nameEspace.name like tenant.name+'(deleted%' or nameEspace.name = tenant.name )
where 
  userProvider.IS_ACTIVE = 1
  and tenant.NAME != userProvider.NAME
order by tenant.ID
OPEN @getCursorID
FETCH NEXT
FROM @getCursorID
INTO @ID,@Name1

WHILE @@FETCH_STATUS = 0
BEGIN
    if (select count(1) from sys.views where name like '%_T' + cast(@ID as varchar(50)) and create_date < @DeployTime) > 1 -- Line to be edited; replace the date time.
    begin
    PRINT 'skipped Tenand with ID [' + cast(@ID as varchar(50)) + '] - select * from sys.views where name like ''%_T' + cast(@ID as varchar(50));
    insert into temp_skipped values (@ID);
	end
    else
    begin

-- Create commands to drop the views associated to the invalid Tenants
    DECLARE @getViewCursorID CURSOR SET @getViewCursorID = CURSOR
    FOR
        SELECT 'IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(''' +  Base_View_Name + '_T' + cast(@ID as varchar(50)) +  ''')) DROP VIEW ' +  Base_View_Name + '_T' + cast(@ID as varchar(50))+ ';' from ossys_Entity where MULTITENANT = 1 and IS_ACTIVE = 1 and Base_View_Name != '' and Base_View_Name is not null
        
        OPEN @getViewCursorID
        FETCH NEXT
        FROM @getViewCursorID
        INTO @DropText
        WHILE @@FETCH_STATUS = 0
        BEGIN
        insert into  temp_command (cmd) values (@DropText);
            FETCH NEXT
            FROM @getViewCursorID
            INTO @DropText
    END
    CLOSE @getViewCursorID
    DEALLOCATE @getViewCursorID

-- create delete commands for OSSYS_TABLES
set @IdList=concat(concat(@IdList,','),@id);
    insert into  temp_command (cmd) values ('DELETE from ossys_Site_Property where Tenant_Id = ' + cast(@ID as varchar(50)) + ';');
    insert into  temp_command (cmd) values ('DELETE from ossys_Cyclic_Job where Tenant_Id = ' + cast(@ID as varchar(50)) + ';');
    insert into  temp_command (cmd) values ('DELETE from ossys_Tenant where ID = ' + cast(@ID as varchar(50)) + ';');
END
    FETCH NEXT
    FROM @getCursorID
    INTO @ID,@Name1

END
CLOSE @getCursorID
DEALLOCATE @getCursorID